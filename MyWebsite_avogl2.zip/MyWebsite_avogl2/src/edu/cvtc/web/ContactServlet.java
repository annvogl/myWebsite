package edu.cvtc.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ContactServlet
 */
@WebServlet("/contact")
public class ContactServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// NOTES: Navigation
					final PrintWriter out = response.getWriter();
					out.append("<!doctype html>\n<html>\n<head><link rel='stylesheet' type='text/css' href='css/MyWebsite.css'>\n<title>Ann Vogl's Website</title>\n"
							+ "</head>\n<body>\n<div class='centered-content'>\n");
					out.append("<ul>\n\t <li><a href='home'>Home</a></li>\n");
					out.append("<li><a href='about'>About</a></li>\n");
					out.append("<li><a class='active' href='contact'>Contact</a></li>\n</ul>\n");
					// NOTES: Content
					out.append("<h1>I Would Love to Hear from You</h1>\n");
					out.append("<form class='form' action='#' method='post'>\n");
					out.append("First name:<br>\n<input type='text' value='Mickey'>\n<br><br>\n"
							+ "Last name:<br>\n<input type='text' name='lastname' value='Mouse'>\n<br><br>\n"
							+ "Email:<br>\n<input type='text' name='email' value='@email.com'>\n<br><br>\n"
							+ "Message:<br>\n <input type='textarea' name='message' value='' \n"
							+ "<br><br><br>\n<input type='submit' value='Submit'>\n</form>");
					out.append("</div>\n</body>\n</html>");
					
					  
					  
					  
					  
					  
					  
					  
					  
					  
					  
					  
					 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
