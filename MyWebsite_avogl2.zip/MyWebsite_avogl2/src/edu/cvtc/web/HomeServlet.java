package edu.cvtc.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HomeServlet
 */
@WebServlet("/home")
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// NOTES: Navigation
		final PrintWriter out = response.getWriter();
		out.append("<!doctype html>\n<html>\n<head><link rel='stylesheet' type='text/css' href='css/MyWebsite.css'>\n<title>Ann Vogl's Website</title>\n"
				+ "</head>\n<body>\n<div class='centered-content'>\n");
		out.append("<ul>\n\t <li><a class='active' href='home'>Home</a></li>\n");
		out.append("<li><a href='about'>About</a></li>\n");
		out.append("<li><a href='contact'>Contact</a></li>\n</ul>\n");
		// NOTES: Content
		out.append("<h1>Welcome to My Website</h1>\n");
		out.append("<p>This is my test website for my Chippewa Valley Technical College Java Programming Class. "
				+ "I will highlight some of my photographs and my awesome programming skills. Enjoy. </p>\n");
		out.append("<div class='floatingPhotos'><img src='images/HiddenLakeAdj.jpg' alt='HiddenAction Lake'>\n");
		out.append("<img src='images/Wall.jpg' alt='Wall'></div>\n");
		out.append("</div></body>\n</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
