package edu.cvtc.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class AboutServlet
 */
@WebServlet("/about")
public class AboutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// NOTES: Navigation
			final PrintWriter out = response.getWriter();
			out.append("<!doctype html>\n<html>\n<head><link rel='stylesheet' type='text/css' href='css/MyWebsite.css'>\n<title>Ann Vogl's Website</title>\n"
					+ "</head>\n<body>\n<div class='centered-content'>\n");
			out.append("<ul>\n\t <li><a href='home'>Home</a></li>\n");
			out.append("<li><a class='active' href='about'>About</a></li>\n");
			out.append("<li><a href='contact'>Contact</a></li>\n</ul>\n");
			// NOTES: Content
			out.append("<h1>About Ann Vogl</h1>\n");
			out.append("<div class='portrait'><img src='images/SelfPortrait.jpg' alt='Self portrait'</div>\n");
			out.append("<p>I am a librarian who loves to learn new things. Thus I am taking programming classes to improve my skills.<br/><br/>\n"
					+ "I continually work on my photography skills. You can see the progress on my <a href='https://www.flickr.com/photos/14775881@N08/'>Flickr Page.</a>\n"
					+ "I have also started learning to belly dance and play hockey, both require a lot of focus. <br/><br/>\n"
					+ "I enjoy being outside walking, biking, canoeing, cross country skiing, etc. And thus I could be considered "
					+ "a treehugger. I am trying not to make the world worse. This can become overwhelming thinking of how my daily tasks have an impact.<br/><br/>\n"
					+ "In order to stay sane, I am practicing meditation/mindfulness to be present and understand that I am connected to everything. "
					+ "I am grateful for everyone I know and I wish you all peace and happiness in your lives.</p>\n");
			out.append("</div>\n</body>\n</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
